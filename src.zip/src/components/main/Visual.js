import React from 'react';

function Visual() {
	return (
		<section>
			<h1>Visual</h1>
		</section>
	);
}

export default Visual;
