import React from 'react';

function Content() {
	return (
		<section>
			<h1>Content</h1>
		</section>
	);
}

export default Content;
