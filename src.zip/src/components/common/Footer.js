import React from 'react';

function Footer() {
	return (
		<footer>
			<div className='inner'>
				<p>Footer</p>
			</div>
		</footer>
	);
}

export default Footer;
