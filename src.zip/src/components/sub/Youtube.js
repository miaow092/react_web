import React from 'react';

function Youtube() {
	return (
		<section className='content youtube'>
			<figure></figure>
			<div className='inner'>
				<h1>Youtube</h1>
			</div>
		</section>
	);
}

export default Youtube;
