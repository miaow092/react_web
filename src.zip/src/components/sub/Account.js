import React from 'react';

function Account() {
	return (
		<section className='content accout'>
			<figure></figure>

			<div className='inner'>
				<h1>Accout</h1>
			</div>
		</section>
	);
}

export default Account;
