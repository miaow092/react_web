import React from 'react';

function Shop() {
	return (
		<section className='content shop'>
			<figure></figure>
			<div className='inner'>
				<h1>Shop</h1>
			</div>
		</section>
	);
}

export default Shop;
