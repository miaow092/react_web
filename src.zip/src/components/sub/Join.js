import React from 'react';

function Join() {
	return (
		<section className='content join'>
			<figure></figure>
			<div className='inner'>
				<h1>Join</h1>
			</div>
		</section>
	);
}

export default Join;
