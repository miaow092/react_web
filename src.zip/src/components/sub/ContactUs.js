import React from 'react';

function ContactUs() {
	return (
		<section className='content contactUs'>
			<figure></figure>
			<div className='inner'>
				<h1>Contact Us</h1>
			</div>
		</section>
	);
}
export default ContactUs;
