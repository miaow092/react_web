import React from 'react';

function About() {
	return (
		<section className='content about'>
			<figure></figure>

			<div className='inner'>
				<h1>About</h1>
			</div>
		</section>
	);
}

export default About;
